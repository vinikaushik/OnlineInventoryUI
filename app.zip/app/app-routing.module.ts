import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderListComponent } from './order-list/order-list.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { OrderDetailComponent } from './order-detail/order-detail.component';
import { ThankyouOrderComponent } from './thankyou-order/thankyou-order.component';


const routes: Routes = [
  {path:"order-list", component:OrderListComponent},
  {path:"order-checkout", component:CheckoutComponent},
  //{path:"order-detail/:id", component:OrderDetailComponent},
  {path:'order-detail',  component:OrderDetailComponent},
  {path:'order-detail/:return',  component:OrderDetailComponent},
  {path:'thankyou', component:ThankyouOrderComponent},  
  {path:'',  component:CheckoutComponent},
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { } export const 
RoutingComponent = [OrderListComponent,CheckoutComponent,OrderDetailComponent];
