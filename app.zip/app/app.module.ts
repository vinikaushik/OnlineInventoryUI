import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule, RoutingComponent } from './app-routing.module';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { MatTableModule } from '@angular/material/table';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {IvyCarouselModule} from 'angular-responsive-carousel';
import {DatePipe} from '@angular/common';
import { MaterialModule } from './material.module';
//import { CdkTableModule} from '@angular/cdk/table';
//import {DataSource} from '@angular/cdk/table';
//import {MatHeaderRowModule} from '@angular/cdk/'

import { AppComponent } from './app.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { OrderListComponent } from './order-list/order-list.component';
import {OrderserviceService} from './orderservice.service';
import { OrderDetailComponent } from './order-detail/order-detail.component';
import { ThankyouOrderComponent } from './thankyou-order/thankyou-order.component';




@NgModule({
  declarations: [
    AppComponent,
    CheckoutComponent,
    OrderListComponent,
    RoutingComponent,
    OrderDetailComponent,
    ThankyouOrderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    MatTableModule,
    IvyCarouselModule,
    MaterialModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    CommonModule
  ],
  providers: [OrderserviceService,DatePipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
