export class Coupon {
  name: String
  discountAmount: number
  discountType : String
}
