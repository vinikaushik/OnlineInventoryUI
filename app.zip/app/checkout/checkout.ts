export class Checkout{
  id: string
  // address: string
  street: string
  name: string
  firstName: string
  middleName: string
  lastName: string
  email : string
  phoneNumber: string
  pincode: string
  Locality: string
  city: string
  state: string
  landmark: string
  other: string
  address: string
  address1: string
  country: string
}
